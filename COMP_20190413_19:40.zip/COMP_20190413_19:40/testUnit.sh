#!/bin/bash
	
	filepath="./tests"
	filename=$(echo $1|cut -d . -f1)
	cat "./$filepath/$filename.c"
	make --no-print-directory back file=$filename
	output2=$($filepath"/a.out")
	return2=$(echo $?)
	echo "\noutput comp:"$output2
	echo "return value comp:"$return2"\n"
	gcc -w "$filepath/$filename.c" -o "$filepath/a.out"
	output1=$($filepath/a.out)
	return1=$(echo $?)
	echo "\noutput gcc:"$output1
	echo "return value gcc:"$return1"\n"
	if [ "$output1" = "$output2" ] && [ "$return1" = "$return2" ] ;then
		echo "unit test OK"	
	else
		echo "unit test KO"
	fi	
	rm -rf $filepath/$filename.o $filepath/$filename.s $filepath/a.out
