int main() {
	int a, b;
	a=5;
	b=a;
	return a;
}
