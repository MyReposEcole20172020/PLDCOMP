int square(int x){
	return x*x;
}
int main(){
	int x=10;
	int s=square(x);
	return s;
}
